package com.example.czasmw;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.TextView;

import java.time.LocalTime;
import java.time.ZoneId;
import java.util.Timer;
import java.util.TimerTask;

public class TimeActivity extends AppCompatActivity {

    TextView localView, tokyoTime, londonTime, newYorkTime, buttonClickedTime;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_time);
        buttonClickedTime = findViewById(R.id.buttonClickedTime);
        localView = findViewById(R.id.textView3);
        tokyoTime = findViewById(R.id.tokyoTime);
        londonTime = findViewById(R.id.londonTime);
        newYorkTime = findViewById(R.id.newYorkTime);

        final Intent intent = getIntent();
        buttonClickedTime.setText(intent.getStringExtra("LOCALTIME"));

        Timer timer = new Timer();
        TimerTask task = new TimerTask() {
            public void run() {

                refresh(intent);
            }
        };

        timer.schedule(task,1000, 1000);

    }

    private void refresh(Intent intent){
        localView.setText(String.valueOf(LocalTime.now(ZoneId.of("Europe/Warsaw")).withNano(0)));
        tokyoTime.setText(String.valueOf(LocalTime.now(ZoneId.of("Asia/Tokyo")).withNano(0)));
        londonTime.setText(String.valueOf(LocalTime.now(ZoneId.of("Europe/London")).withNano(0)));
        newYorkTime.setText(String.valueOf(LocalTime.now(ZoneId.of("America/Indianapolis")).withNano(0)));

    }
}

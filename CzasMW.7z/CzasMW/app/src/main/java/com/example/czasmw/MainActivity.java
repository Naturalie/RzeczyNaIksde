package com.example.czasmw;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import java.sql.Time;
import java.time.LocalTime;
import java.time.ZoneId;
import java.util.TimeZone;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    public void time(View view){
        Button bTime = findViewById(R.id.checkTime);
        LocalTime localTime = LocalTime.now(ZoneId.of("Europe/Warsaw")).withNano(0);
        Intent intent = new Intent(this, TimeActivity.class);
        intent.putExtra("LOCALTIME",localTime.toString());
        startActivity(intent);

    }
}

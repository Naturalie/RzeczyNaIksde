package com.example.calculator;

import android.content.res.Configuration;
import android.support.v4.math.MathUtils;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.TextView;

import org.w3c.dom.Text;

public class MainActivity extends AppCompatActivity {
    private TextView textView;
    private String resultValue = "";
    private float value = 0;
    private String operation = "";
    private boolean firstOpeartion = true;
    private boolean isEqUsed = false;
    private int countOperations  = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        this.getSupportActionBar().hide();
        setContentView(R.layout.activity_main);
        textView = findViewById(R.id.editText);
        setButtonsListener();
        if(savedInstanceState != null){
            this.resultValue = savedInstanceState.getString("stringKey");
            this.value = savedInstanceState.getFloat("floatKey");
            if(this.resultValue.equals("")) textView.setText("0");
            else{
                this.textView.setText(this.resultValue);
                this.firstOpeartion = false;
            }
        }
    }


    public void setButtonsListener() {
        findViewById(R.id.b0).setOnClickListener(actionOfButtonListener);
        findViewById(R.id.b1).setOnClickListener(actionOfButtonListener);
        findViewById(R.id.b2).setOnClickListener(actionOfButtonListener);
        findViewById(R.id.b3).setOnClickListener(actionOfButtonListener);
        findViewById(R.id.b4).setOnClickListener(actionOfButtonListener);
        findViewById(R.id.b5).setOnClickListener(actionOfButtonListener);
        findViewById(R.id.b6).setOnClickListener(actionOfButtonListener);
        findViewById(R.id.b7).setOnClickListener(actionOfButtonListener);
        findViewById(R.id.b8).setOnClickListener(actionOfButtonListener);
        findViewById(R.id.b9).setOnClickListener(actionOfButtonListener);
        findViewById(R.id.bac).setOnClickListener(actionOfButtonListener);
        findViewById(R.id.bsub).setOnClickListener(actionOfButtonListener);
        findViewById(R.id.badd).setOnClickListener(actionOfButtonListener);
        findViewById(R.id.bper).setOnClickListener(actionOfButtonListener);
        findViewById(R.id.beq).setOnClickListener(actionOfButtonListener);
        findViewById(R.id.bmulti).setOnClickListener(actionOfButtonListener);
        findViewById(R.id.bdiv).setOnClickListener(actionOfButtonListener);
        findViewById(R.id.badd).setOnClickListener(actionOfButtonListener);
        findViewById(R.id.bs).setOnClickListener(actionOfButtonListener);
        findViewById(R.id.bpm).setOnClickListener(actionOfButtonListener);
        findViewById(R.id.blog).setOnClickListener(actionOfButtonListener);
        findViewById(R.id.xpow).setOnClickListener(actionOfButtonListener);
        findViewById(R.id.xnew).setOnClickListener(actionOfButtonListener);
        findViewById(R.id.xtri).setOnClickListener(actionOfButtonListener);
        findViewById(R.id.bsqr).setOnClickListener(actionOfButtonListener);
    }

    @Override
    protected  void onSaveInstanceState(Bundle outState){
        super.onSaveInstanceState(outState);
        outState.putString("stringKey",this.resultValue);
        outState.putFloat("floatKey",this.value);
    }
    private void updateResultValue(String string){
        if(string.equals(".") && this.resultValue.equals("")){
            this.resultValue = "0.";
            textView.setText(this.resultValue);
            firstOpeartion = false;
        }
        else if(this.firstOpeartion){
            this.resultValue = string;
            firstOpeartion = false;
            textView.setText(this.resultValue);
        }
        else if(this.resultValue.length() == 1 && this.resultValue.equals("0") && !string.equals(".") && this.firstOpeartion == false){
            this.resultValue = string;
            textView.setText(this.resultValue);
        }
        else{
            this.resultValue += string;
            textView.setText(this.resultValue);
        }
    }
    private void resetApp(){
        this.value= 0;
        this.countOperations = 0;
        this.resultValue = "";
        this.operation = "";
        this.firstOpeartion = true;
    }

    private void currentOperation(String string){
        switch(string) {
            case "+":
                this.value += Float.valueOf(this.resultValue);
                textView.setText(String.valueOf(this.value));
                this.resultValue = "";
                break;
            case "-":
                this.value -= Float.valueOf(this.resultValue);
                textView.setText(String.valueOf(this.value));
                this.resultValue = "";
                break;
            case "X":
                this.value *= Float.valueOf(this.resultValue);
                textView.setText(String.valueOf(this.value));
                this.resultValue = "";
                break;
            case "/":
                if(resultValue.equals("0") || resultValue.equals("0."))
                    textView.setText("Nie dzieli sie przez 0.");
                else {
                    this.value /= Float.valueOf(this.resultValue);
                    textView.setText(String.valueOf(this.value));
                    this.resultValue = "";
                }
                break;
            case "+/-":
                if(resultValue.equals("") || resultValue.equals("0"))
                textView.setText(this.resultValue);
                else {
                    this.value = Float.valueOf(this.resultValue) * -1;
                    textView.setText(String.valueOf(this.value));
                    this.resultValue = "";
                }
                break;
            case "LOG10":
                this.textView.setText(String.valueOf(Math.log10(Float.valueOf(this.resultValue))));
                this.resultValue = "";
                break;
            case "x^2":
                this.value = Float.valueOf(this.resultValue) * Float.valueOf(this.resultValue);
                textView.setText(String.valueOf(this.value));
               this.resultValue = "";
                break;
            case "x^3":
                this.value = Float.valueOf(this.resultValue) * Float.valueOf(this.resultValue) * Float.valueOf(this.resultValue);
                textView.setText(String.valueOf(this.value));
                this.resultValue = "";
                break;
            case "x!":
                this.textView.setText(String.valueOf(xNewResult(Float.valueOf(resultValue))));
                this.resultValue = "";
                break;
            case "SQRT(X)":
                this.textView.setText(String.valueOf(Math.sqrt(Float.valueOf(resultValue))));
                this.resultValue = "";
                break;
            case "AC":
                resetApp();
                break;
            default:
                break;
        }
    }
    private float xNewResult(float value){
        float temp = 1;
        for(int i = 1; i <= value; i++){
            temp *= i;
        }
        return temp;
    }
    private void setCurrentOperation(String string){
        if(string.equals("=")) {
            if (countOperations > 0) {
                if (this.resultValue.length() == 0) {
                    textView.setText(String.valueOf(this.value));
                    resetApp();
                } else{
                    currentOperation(this.operation);
                    resetApp();
                }
            }
        }
        else{
            if(countOperations == 0 &&(string.equals("x^2") || string.equals("LOG10") || string.equals("x^3") || string.equals("x!") || string.equals("SQRT(X)"))){
                currentOperation(string);
                countOperations++;
            }
            else if(countOperations == 0){
                this.operation = string;
                if(this.resultValue.length() > 0){
                    this.value = Float.valueOf(this.resultValue);
                }
                this.resultValue = "";
                countOperations++;
            }
            else if(countOperations > 0 && this.resultValue.equals("")){
                this.operation = string;
            }
            else if(countOperations > 0 && !this.resultValue.equals("")){
                currentOperation(string);
            }
        }

    }

    private View.OnClickListener actionOfButtonListener = new View.OnClickListener() {
        @Override
        public void onClick(View view) {
           switch(view.getId()){
               case R.id.b0:
                   if(resultValue.length() == 1){
                       if(!(resultValue.charAt(0) == '0')) updateResultValue("0");
                   }
                   else updateResultValue("0");
                   break;
               case R.id.b1:
               case R.id.b2:
               case R.id.b3:
               case R.id.b4:
               case R.id.b5:
               case R.id.b6:
               case R.id.b7:
               case R.id.b8:
               case R.id.b9:
                   updateResultValue(String.valueOf(((Button)view).getText()));
                   break;
               case R.id.bs:
                   if(!resultValue.contains(".")){
                       updateResultValue(".");
                   }
                   break;
               case R.id.bac:
               case R.id.bpm:
               case R.id.bsub:
               case R.id.bmulti:
               case R.id.badd:
               case R.id.bdiv:
               case R.id.beq:
               case R.id.xpow:
               case R.id.xtri:
               case R.id.xnew:
               case R.id.blog:
               case R.id.bsqr:
                   setCurrentOperation(String.valueOf(((Button)view).getText()));
                   break;
           }
        }
    };
}


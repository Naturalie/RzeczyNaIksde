package com.example.chat_kotlin

import android.support.v7.widget.RecyclerView
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import kotlinx.android.synthetic.main.items_view.view.*



class Items(private val clickListener: (MsgClass) -> Unit) : RecyclerView.Adapter<Items.MyViewHolder>() {

    private var classList : MutableList<MsgClass> = mutableListOf()

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): MyViewHolder {

        val view = LayoutInflater.from(parent.context).inflate(R.layout.items_view ,parent,false)
        return MyViewHolder(view)
    }

    override fun getItemCount(): Int {
        return classList.size
    }

    override fun onBindViewHolder(holder: MyViewHolder, position: Int) {
        holder.bind(classList[position], clickListener)
    }

    fun setMsgListItems(msgClassList: MutableList<MsgClass>){
        this.classList = msgClassList
        notifyDataSetChanged()
    }




    class MyViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView){
        fun bind(item: MsgClass, clickListener: (MsgClass) -> Unit) {
            itemView.user_content.text = item.content
            itemView.user_login.text = item.login
            itemView.user_date.text = item.date
            itemView.setOnClickListener { clickListener(item)}
        }
    }
}
package com.example.chat_kotlin

import retrofit2.Call
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import retrofit2.http.*

interface MsgInterface {
    @GET("messages")
    fun getMsg() : Call<MutableList<MsgClass>>


    @POST("message")
    fun createMsg(@Body m : SendMsg) : Call<MsgClass>

    @PUT("message/{id}")
    fun updateMsg(@Path("id") id : String, @Body m : SendMsg) : Call<MsgClass>

    @DELETE("message/{id}")
    fun deleteMsg(@Path("id") id : String) : Call<MsgClear>

    companion object {

        private const val BaseUrl = "http://tgryl.pl/shoutbox/"

        fun create() : MsgInterface {
            val retrofit = Retrofit.Builder()
                .baseUrl(BaseUrl)
                .addConverterFactory(GsonConverterFactory.create())
                .build()

            return retrofit.create(MsgInterface::class.java)
        }


    }
}
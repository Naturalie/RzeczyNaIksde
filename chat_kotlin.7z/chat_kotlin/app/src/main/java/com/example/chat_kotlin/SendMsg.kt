package com.example.chat_kotlin


import com.google.gson.annotations.SerializedName

data class SendMsg(
    @SerializedName("content")
    val content: String,
    @SerializedName("login")
    val login: String
)
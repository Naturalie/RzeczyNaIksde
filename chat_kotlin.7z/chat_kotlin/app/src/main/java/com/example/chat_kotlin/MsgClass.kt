package com.example.chat_kotlin


import com.google.gson.annotations.SerializedName

data class MsgClass(
    @SerializedName("content")
    val content: String,
    @SerializedName("date")
    val date: String,
    @SerializedName("id")
    val id: String,
    @SerializedName("login")
    val login: String
)
package com.example.chat_kotlin

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.support.v4.view.GravityCompat
import android.support.v7.app.ActionBarDrawerToggle
import android.view.MenuItem
import android.support.v4.widget.DrawerLayout
import android.support.design.widget.NavigationView
import android.support.v7.app.AppCompatActivity
import android.support.v7.widget.LinearLayoutManager
import android.support.v7.widget.RecyclerView
import android.support.v7.widget.Toolbar
import android.util.Log
import android.view.View
import android.view.inputmethod.InputMethodManager
import android.widget.Toast
import kotlinx.android.synthetic.main.content_main.*
import retrofit2.*

class MainActivity : AppCompatActivity(), NavigationView.OnNavigationItemSelectedListener {
    private var uLogin: String? = ""
    private lateinit var itemsView: RecyclerView
    lateinit var items: Items

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        val toolbar: Toolbar = findViewById(R.id.toolbar)
        setSupportActionBar(toolbar)

        val drawerLayout: DrawerLayout = findViewById(R.id.drawer_layout)
        val navView: NavigationView = findViewById(R.id.nav_view)
        val toggle = ActionBarDrawerToggle(
            this, drawerLayout, toolbar, R.string.navigation_drawer_open, R.string.navigation_drawer_close
        )
        drawerLayout.addDrawerListener(toggle)
        toggle.syncState()

        navView.setNavigationItemSelectedListener(this)

        val sharedPref = getSharedPreferences(R.string.FILE_KEY.toString(), Context.MODE_PRIVATE) ?: return
        uLogin = sharedPref.getString(R.string.LOGIN_KEY.toString(), null )

        if(uLogin==null){
            val intent = Intent(this, LoginActivity::class.java)
            startActivity(intent)
        }

        itemsView = recyclerview
        items = Items { item -> itemClicked(item) }
        itemsView.layoutManager = LinearLayoutManager(this)
        itemsView.adapter = items

        getNewMsg()

        send_button.setOnClickListener{
            sendMsg(input_message.text.toString())
            input_message.text.clear()
            input_message.clearFocus()
            it.hideKeyboard()
        }

    }
    companion object{
        const val UPDATE_DELETE_MESSAGE_REQ_CODE: Int = 1
        const val DATA_TYPE = "TYPE"
        const val DATA_UPDATE = "UPDATE"
        const val DATA_DELETE = "DELETE"
        const val DATA_USER_LOGIN = "l"
        const val DATA_USER_CONTENT = "c"
        const val DATA_USER_ID = "id"
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)

        if(requestCode == UPDATE_DELETE_MESSAGE_REQ_CODE){
            if(resultCode == Activity.RESULT_OK){

                if(data?.getStringExtra(DATA_TYPE) == DATA_UPDATE){

                    val login = data.getStringExtra(DATA_USER_LOGIN)
                    val content = data.getStringExtra(DATA_USER_CONTENT)
                    val id = data.getStringExtra(DATA_USER_ID)

                    updateMsg(id, SendMsg(content, login))

                }else if(data?.getStringExtra(DATA_TYPE) == DATA_DELETE){
                    val id = data.getStringExtra(DATA_USER_ID)
                    deleteMsg(id!!)
                }
            }
        }
    }

    private fun itemClicked(item : MsgClass) {
        val intent = Intent(this, MsgEdition::class.java)
        intent.putExtra("login", item.login)
        intent.putExtra("content", item.content)
        intent.putExtra("id", item.id)
        intent.putExtra("user_login", uLogin)
        startActivityForResult(intent, UPDATE_DELETE_MESSAGE_REQ_CODE)
    }

    private fun View.hideKeyboard() {
        val imm = context.getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
        imm.hideSoftInputFromWindow(windowToken, 0)
    }


    private fun sendMsg(m: String ){
            MsgInterface.create().createMsg(SendMsg(m, uLogin!!))
                .enqueue(object : Callback<MsgClass>{
                    override fun onResponse(call: Call<MsgClass>, response: Response<MsgClass>) {
                        getNewMsg()
                    }

                    override fun onFailure(call: Call<MsgClass>, t: Throwable) {
                        Toast.makeText(applicationContext, t.message, Toast.LENGTH_LONG).show()
                    }

                })
    }


    private fun deleteMsg(i: String ){
            MsgInterface.create().deleteMsg(i)
                .enqueue(object : Callback<MsgClear>{
                    override fun onFailure(call: Call<MsgClear>, t: Throwable) {
                        Log.w("Delete",t.message)
                    }

                    override fun onResponse(call: Call<MsgClear>, response: Response<MsgClear>) {
                        getNewMsg()
                    }
                })
        }

    private fun updateMsg(i: String, body: SendMsg){
            MsgInterface.create().updateMsg(i, body)
                .enqueue(object : Callback<MsgClass>{
                    override fun onFailure(call: Call<MsgClass>, t: Throwable) {
                        Log.w("update",t.message)
                        Toast.makeText(this@MainActivity, "update Fail", Toast.LENGTH_LONG).show()
                    }

                    override fun onResponse(call: Call<MsgClass>, response: Response<MsgClass>) {
                        getNewMsg()
                        Toast.makeText(this@MainActivity, "update DONE", Toast.LENGTH_LONG).show()
                    }

                })
        }
    fun getNewMsg(){

            val service = MsgInterface.create()
            val call = service.getMsg()


            call.enqueue(object : Callback<MutableList<MsgClass>>{
                override fun onResponse(call: Call<MutableList<MsgClass>>, response: Response<MutableList<MsgClass>>) {
                    if(response.code() == 200){
                        items.setMsgListItems(response.body()!!)
                    }
                }

                override fun onFailure(call: Call<MutableList<MsgClass>>, t: Throwable) {
                    t.printStackTrace()
                }
            })
        }


    override fun onResume() {
        super.onResume()
        val sharedPref = getSharedPreferences(R.string.FILE_KEY.toString(), Context.MODE_PRIVATE) ?: return
        uLogin = sharedPref.getString(R.string.LOGIN_KEY.toString(), null )


        getNewMsg()

    }



    override fun onBackPressed() {
        val drawerLayout: DrawerLayout = findViewById(R.id.drawer_layout)
        if (drawerLayout.isDrawerOpen(GravityCompat.START)) {
            drawerLayout.closeDrawer(GravityCompat.START)
        } else {
            super.onBackPressed()
        }
    }



    override fun onNavigationItemSelected(item: MenuItem): Boolean {
        // Handle navigation view item clicks here.
        when (item.itemId) {
            R.id.nav_home -> {

            }
            R.id.settings -> {
                val intent = Intent(this, LoginActivity::class.java)
                startActivity(intent)
            }

        }
        val drawerLayout: DrawerLayout = findViewById(R.id.drawer_layout)
        drawerLayout.closeDrawer(GravityCompat.START)
        return true
    }
}

package com.example.weathermw;
import retrofit2.Call;
import retrofit2.http.GET;
import retrofit2.http.Query;

public interface WeatherInterface {
    @GET("weather")
    Call<WeatherTypes> getWeather(@Query("q") String city_name,
                                  @Query("APPID") String appid,
                                  @Query("units") String units
    );

}

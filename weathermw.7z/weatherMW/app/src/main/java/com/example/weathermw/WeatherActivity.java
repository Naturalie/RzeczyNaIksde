package com.example.weathermw;

import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.StrictMode;
import android.support.v4.widget.SwipeRefreshLayout;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.widget.ImageView;
import android.widget.TextView;

import java.io.IOException;
import java.io.InputStream;
import java.net.URL;
import java.text.SimpleDateFormat;
import java.time.LocalTime;
import java.time.temporal.ChronoUnit;
import java.util.HashMap;
import java.util.List;
import java.util.Timer;
import java.util.TimerTask;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class WeatherActivity extends AppCompatActivity{
    TextView city, temp, pressure, humidity, tempmin, tempmax;
    ImageView imageView;
    String city1;
    SwipeRefreshLayout pullToRefresh;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_weather);
        Intent intent = getIntent();

        StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
        StrictMode.setThreadPolicy(policy);

        imageView = findViewById(R.id.imageView);
        city = findViewById(R.id.textView3);
        temp = findViewById(R.id.degreeShow);
        tempmax = findViewById(R.id.tempMaxShow);
        tempmin = findViewById(R.id.tempMinShow);
        humidity = findViewById(R.id.percentageShow);
        pressure = findViewById(R.id.pressureShow);

        city1 = intent.getStringExtra("WT");
        city.setText(city1);
        getWeather(city1);

        Timer timer = new Timer();
        TimerTask task = new TimerTask() {
            public void run() {
               getWeather(city1);
            }
        };

        timer.schedule(task,0, 5000);


        pullToRefresh = findViewById(R.id.pullToRefresh);
        pullToRefresh.setOnRefreshListener(new SwipeRefreshLayout.OnRefreshListener() {
            @Override
            public void onRefresh() {
                getWeather(city1);
                pullToRefresh.setRefreshing(false);
            }
        });

    }
    private void getWeather(String citi){

        Retrofit retrofit = new Retrofit.Builder()
                .baseUrl("http://api.openweathermap.org/data/2.5/")
                .addConverterFactory(GsonConverterFactory.create())
                .build();
        WeatherInterface gson = retrofit.create(WeatherInterface.class);
        final String appid = "749561a315b14523a8f5f1ef95e45864";
        Call<WeatherTypes> call = gson.getWeather(citi, appid, "metric");
        call.enqueue(new Callback<WeatherTypes>(){
            @Override
            public void onResponse(Call<WeatherTypes> call, Response<WeatherTypes> response) {
                if (!response.isSuccessful()) {
                    finish();
                } else {

                    WeatherTypes weather = response.body();
                    temp.setText(weather.getTemp());
                    pressure.setText(weather.getPressure());
                    tempmin.setText(weather.getTemp_min());
                    tempmax.setText(weather.getTemp_max());
                    tempmax.setText(weather.getIcon());

                    try {
                        String URLs = "http://openweathermap.org/img/w/10d.png";
                        InputStream is = new java.net.URL(URLs).openStream();
                        Bitmap Logo = BitmapFactory.decodeStream(is);
                        imageView.setImageBitmap(Logo);
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }
            }

            @Override
            public void onFailure(Call<WeatherTypes> call, Throwable t)
            {
                finish();
            }
        });
    }

}


package com.example.weathermw;
import com.google.gson.annotations.SerializedName;
public class WeatherTypes {

    @SerializedName("main")
    public WeatherClass weatherClass;

    @SerializedName("temp")
    public String getTemp(){
        return weatherClass.getTemp().toString() + " °C";
    }
    @SerializedName("pressure")
    public String getPressure() {
        return weatherClass.getPressure().toString() + "hPa";
    }
    @SerializedName("humidity")
    public String getHumidity() {
        return weatherClass.getHumidity().toString() + " %";
    }
    @SerializedName("temp_min")
    public String getTemp_min() {
        return weatherClass.getTemp_min().toString() + " °C";
    }
    @SerializedName("temp_max")
    public String getTemp_max() {
        return weatherClass.getTemp_max().toString() + " °C";
    }
}

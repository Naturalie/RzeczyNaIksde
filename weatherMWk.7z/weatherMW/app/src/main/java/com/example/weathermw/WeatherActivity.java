package com.example.weathermw;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.widget.TextView;

import java.net.URL;
import java.text.SimpleDateFormat;
import java.util.HashMap;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class WeatherActivity extends AppCompatActivity {
    TextView city, temp, pressure, humidity, tempmin, tempmax;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_weather);
        Intent intent = getIntent();

        city = findViewById(R.id.textView3);
        temp = findViewById(R.id.degreeShow);
        tempmax = findViewById(R.id.tempMaxShow);
        tempmin = findViewById(R.id.tempMinShow);
        humidity = findViewById(R.id.percentageShow);
        pressure = findViewById(R.id.pressureShow);

        String city1 = intent.getStringExtra("WT");
        city.setText(city1);
        getWeather(city1);
    }
    private void getWeather(String citi){

        Retrofit retrofit = new Retrofit.Builder()
                .baseUrl("http://api.openweathermap.org/data/2.5/")
                .addConverterFactory(GsonConverterFactory.create())
                .build();
        WeatherInterface gson = retrofit.create(WeatherInterface.class);
        final String appid = "749561a315b14523a8f5f1ef95e45864";
        Call<WeatherTypes> call = gson.getWeather(citi, appid, "metric");
        call.enqueue(new Callback<WeatherTypes>(){
            @Override
            public void onResponse(Call<WeatherTypes> call, Response<WeatherTypes> response) {
                if (!response.isSuccessful()) {
                    finish();
                } else {

                    WeatherTypes weather = response.body();
                    temp.setText(weather.getTemp());
                    pressure.setText(weather.getPressure());
                    humidity.setText(weather.getHumidity());
                    tempmin.setText(weather.getTemp_min());
                    tempmax.setText(weather.getTemp_max());
                }
            }

            @Override
            public void onFailure(Call<WeatherTypes> call, Throwable t){
                finish();
            }
        });
    }

}

package com.example.weathermw;

import android.content.Intent;
import android.content.SharedPreferences;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.EditText;

import java.text.Normalizer;
import java.util.logging.Logger;

public class MainActivity extends AppCompatActivity {
    EditText weatherText;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        weatherText = findViewById(R.id.textView);
        loadData();

    }
    public void sendWeather(View view){


        String yourText = weatherText.getText().toString();
        saveData(yourText);
        yourText = Normalizer.normalize(yourText, Normalizer.Form.NFD);
        yourText = yourText.replaceAll("[^\\p{ASCII}]", "");
        Intent intent = new Intent(this, WeatherActivity.class);
        intent.putExtra("WT", yourText);
        startActivity(intent);


    }

    public void saveData(String output){
        SharedPreferences sharedPreferences = getSharedPreferences("sp", MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putString("CITY_KEY", output);
        editor.apply();
    }
    public void loadData(){
        SharedPreferences sharedPreferences = getSharedPreferences("sp", MODE_PRIVATE);
        String date = sharedPreferences.getString("CITY_KEY", "Tarnow");
        weatherText.setText(date);
    }


}
